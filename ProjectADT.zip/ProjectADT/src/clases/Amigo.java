package clases;

/*******************************************************************************
 * 2017, All rights reserved.
 *******************************************************************************/

// Start of user code (user defined imports)

// End of user code

/**
 * Description of Amigo.
 * 
 * @author casa
 */
public class Amigo {
	/**
	 * Description of the property nombre.
	 */
	private String nombre = "";

	// Start of user code (user defined attributes for Amigo)

	// End of user code

	/**
	 * The constructor.
	 */
	public Amigo() {
		// Start of user code constructor for Amigo)
		super();
		// End of user code
	}

	// Start of user code (user defined methods for Amigo)

	// End of user code
	/**
	 * Returns nombre.
	 * @return nombre 
	 */
	public String getNombre() {
		return this.nombre;
	}

	/**
	 * Sets a value to attribute nombre. 
	 * @param newNombre 
	 */
	public void setNombre(String newNombre) {
		this.nombre = newNombre;
	}

}
